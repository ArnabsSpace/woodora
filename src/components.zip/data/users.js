const users = [
  {
    id: 1,
    email: "demo@woodora.com",
    password: "woodora123",
    name: "Demo User",
  },
  {
    id: 2,
    email: "test@woodora.com",
    password: "test123",
    name: "Test User",
  },
];

export default users;
