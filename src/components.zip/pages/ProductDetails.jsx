import ProductDetailsSection from "../components/ProductDetailsSection";
export default function ProductDetails(){
    return (
        <>
            <ProductDetailsSection />
        </>
    )
}