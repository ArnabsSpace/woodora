export default function Shipping() {
    return (
        <>
            <h1>worked shipping</h1>
        </>
    )
}