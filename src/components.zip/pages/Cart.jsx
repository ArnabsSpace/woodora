import CartSummary from '../components/CartSummary';
export default function Cart(){
    return (
        <>
        <CartSummary />
        </>
    )
}